import pandas as pd
import matplotlib.pyplot as plt
import sys
#create dataframe from csv
df=pd.read_csv('boxplot_data', sep='\t', header=None, names=['col1', 'col2', 'col3'])
plotMap=[]

#create a list of lists where each list will have a corresponding box plot
plotMap.append(df['col2'].dropna().tolist())
plotMap.append(df['col3'].dropna().tolist())

#plotting
plt.boxplot(plotMap)

#specifying labels
plt.xticks([1,2], ['2011-12','2012-13'])
plt.xlabel("Year")
plt.ylabel("Proposals not found suitable(State-Wise)")


plt.legend()
plt.show()